﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev7
{
    internal class Araba
    {
        public string Marka { get; set; }
        public string Model { get; set; }
        public double BenzinTuketimi { get; set; } // Benzin tüketimi litre/100km olarak belirlenecek

        public Araba(string marka, string model, double benzinTuketimi)
        {
            Marka = marka;
            Model = model;
            BenzinTuketimi = benzinTuketimi;
        }

        public double YillikBenzinTuketimi(double yil)
        {
            double toplamKilometre = 15000; // Yıllık ortalama kilometre
            return (toplamKilometre / 100) * BenzinTuketimi; // Yıllık benzin tüketimi
        }
    }
}
