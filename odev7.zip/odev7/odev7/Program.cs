﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Araba audiA4 = new Araba("Audi", "A4", 7.0);  // Benzin tüketimi 7.0 litre/100 km
            Araba bmwX5 = new Araba("BMW", "X5", 9.5);   // Benzin tüketimi 9.5 litre/100 km
            Araba cheryTiggo7Pro = new Araba("Chery", "Tiggo 7 Pro", 8.0); // Benzin tüketimi 8.0 litre/100 km

            // Arabaların listesini oluşturuyoruz
            List<Araba> arabalar = new List<Araba> { audiA4, bmwX5, cheryTiggo7Pro };

            double toplamBenzinTuketimi = 0;

            // Her bir araba için benzin tüketimini hesaplıyoruz
            foreach (var araba in arabalar)
            {
                double yillikBenzin = araba.YillikBenzinTuketimi(2025);
                Console.WriteLine($"{araba.Marka} {araba.Model} - Yıllık Benzin Tüketimi: {yillikBenzin} litre");
                toplamBenzinTuketimi += yillikBenzin;
            }

            Console.WriteLine($"\nToplam Yıllık Benzin Tüketimi: {toplamBenzinTuketimi} litre");
        }
    }
}
