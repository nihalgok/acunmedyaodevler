﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // While Döngüsü
            int i = 0;
            Console.WriteLine("While Döngüsü:");
            while (i < 5)
            {
                Console.WriteLine(i);
                i++;
            }

            Console.WriteLine(); 

            // Do-While Döngüsü
            i = 0;
            Console.WriteLine("Do-While Döngüsü:");
            do
            {
                Console.WriteLine(i);
                i++;
            } while (i < 5);
        }
    }
}
