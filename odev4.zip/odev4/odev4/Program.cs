﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Arabanızın yaşını girin: ");
            int carAge = int.Parse(Console.ReadLine());

            string result = ArabaDurumuBelirle(carAge);

            Console.WriteLine(result);
        }
        static string ArabaDurumuBelirle(int carAge)
        {
            if (carAge >= 0 && carAge <= 10)
            {
                return "Arabanız yeni";
            }
            else if (carAge >= 11 && carAge <= 20)
            {
                return "Servise götürmeniz gerekebilir";
            }
            else if (carAge >= 21 && carAge <= 30)
            {
                return "Arabanız hurdaya çıkabilir";
            }
            else if (carAge < 0 || carAge > 30)
            {
                return "Ya hiç üretilmedi ya da trafikten men edilmiştir";
            }
            return "";
        }
    }
}

