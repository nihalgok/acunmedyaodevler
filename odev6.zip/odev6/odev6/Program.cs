﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Calisan genelMudur = new Calisan("Tuğba", "Şahbaz", 45000, "Yönetim");
            Calisan mudur = new Calisan("Nihal", "Gök", 40000, "Pazarlama");
            Calisan programci = new Calisan("Rüya", "Kömürcü", 35000, "Yazılım");
            Calisan stajyer = new Calisan("ela", "acar", 10000, "Yazılım");

            Calisan[] calisanlar = { genelMudur, mudur, programci, stajyer };

            foreach (var calisan in calisanlar)
            {
                calisan.BilgileriYazdir();
            }

            decimal toplamMaas = 0;
            foreach (var calisan in calisanlar)
            {
                toplamMaas += calisan.Maas; 
            }

            Console.WriteLine($"Toplam maaş: {toplamMaas} TL");
        }
    }
}
