﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Lütfen yaşınızı girin: ");
            int age = int.Parse(Console.ReadLine());

            string result = YasKategorisiBelirle(age);

            Console.WriteLine(result);
        }
        static string YasKategorisiBelirle(int age)
        {
            if (age >= 0 && age <= 18)
            {
                return "Küçüksünüz";
            }
            else if (age >= 19 && age <= 35)
            {
                return "Gençsiniz";
            }
            else if (age >= 36 && age <= 55)
            {
                return "Yetişkinsiniz";
            }
            else if (age >= 56 && age <= 75)
            {
                return "Yaşlısınız";
            }
            else if (age >= 76 && age <= 99)
            {
                return "Çok yaşlısınız";
            }
            else
            {
                return "Ya hiç doğmadınız ya da çoktan öldünüz...";
            }

        }
    }
}
